#include <iostream>
using namespace std;

const int SIZE = 10;

struct Node {
    int npm;
    float nilai;
    Node* next;
};

void initTable(Node* table[]) {
    for (int i = 0; i < SIZE; i++) {
        table[i] = nullptr;
    }
}

int hashFunction(int npm) {
    return (npm % SIZE + SIZE) % SIZE;
}

void insert(Node* table[], int npm, float nilai) {
    int index = hashFunction(npm);
    Node* cur = table[index];
    while (cur != nullptr) {
        if (cur->npm == npm) {
            cur->nilai = nilai;
            return;
        }
        cur = cur->next;
    }
    Node* baru = new Node;
    baru->npm = npm;
    baru->nilai = nilai;
    baru->next = table[index];
    table[index] = baru;
}

Node* search(Node* table[], int npm) {
    int index = hashFunction(npm);
    Node* cur = table[index];
    while (cur != nullptr) {
        if (cur->npm == npm) {
            return cur;
        }
        cur = cur->next;
    }
    return nullptr;
}

void removeData(Node* table[], int npm) {
    int index = hashFunction(npm);
    Node* cur = table[index];
    Node* prev = nullptr;
    while (cur != nullptr) {
        if (cur->npm == npm) {
            if (prev == nullptr) {
                table[index] = cur->next;
            } else {
                prev->next = cur->next;
            }
            delete cur;
            return;
        }
        prev = cur;
        cur = cur->next;
    }
}

void display(Node* table[]) {
    cout << "\n--- Data Nilai Mahasiswa (Hash Table) ---\n";
    for (int i = 0; i < SIZE; i++) {
        cout << "Index " << i << ": ";
        Node* tmp = table[i];
        while (tmp != nullptr) {
            cout << "(" << tmp->npm << ", " << tmp->nilai << ") -> ";
            tmp = tmp->next;
        }
        cout << "NULL\n";
    }
}

int main() {
    Node* table[SIZE];
    initTable(table);

    int pilihan, npm;
    float nilai;

    while (true) {
        cout << "\n--- Menu Input Nilai Mahasiswa ---";
        cout << "\n1. Input Nilai Mahasiswa";
        cout << "\n2. Cari Nilai Mahasiswa";
        cout << "\n3. Hapus Nilai Mahasiswa";
        cout << "\n4. Tampilkan Semua Nilai";
        cout << "\n5. Exit (Keluar)";
        cout << "\nMasukkan pilihan Anda: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                cout << "Masukkan NPM (integer): ";
                cin >> npm;
                cout << "Masukkan Nilai (float): ";
                cin >> nilai;
                insert(table, npm, nilai);
                cout << "Data (NPM: " << npm << ", Nilai: " << nilai << ") berhasil ditambahkan.\n";
                break;
            
            case 2:{
                cout << "Masukkan NPM yang ingin dicari: ";
                cin >> npm;
                Node* hasil = search(table, npm);
                if (hasil != nullptr) {
                    cout << "NPM " << npm << " ditemukan dengan nilai = " << hasil->nilai << endl;
                } else {
                    cout << "Data NPM " << npm << " tidak ditemukan.\n";
                }
                break;
            }

            case 3:{
                cout << "Masukkan NPM yang datanya ingin dihapus: ";
                cin >> npm;
                if (search(table, npm) != nullptr) {
                    removeData(table, npm);
                    cout << "Data NPM " << npm << " berhasil dihapus.\n";
                } else {
                    cout << "Data NPM " << npm << " tidak ditemukan, tidak ada yang dihapus.\n";
                }
                break;
            }
            
            case 4:{
                display(table);
                break;
            }

            case 5:{
                cout << "Keluar dari program. Terima kasih!\n";
                return 0;
            }

            default:{
                cout << "Pilihan tidak valid. Silakan coba lagi.\n";
            }
        }
    }

    return 0;
}