#include <iostream>
using namespace std;

struct Node {
    int nilai;
    Node *left;
    Node *right;

    Node(int val) : nilai(val), left(nullptr), right(nullptr) {}
};

Node* insertNode(Node* root, int nilai);
bool searchNode(Node* root, int nilai);
void inorder(Node* root);
void preorder(Node* root);
void postorder(Node* root);
int findMin(Node* root);
int findMax(Node* root);
int countNodes(Node* root);
long long sumNilai(Node* root);

int main() {
    Node* root = nullptr;
    int pilih, nilai;

    do {
        cout << "\n===== Sistem Penyimpanan Nilai (BST) =====\n";
        cout << "1. Input Nilai\n";
        cout << "2. Cari Nilai\n";
        cout << "3. Tampilkan In-order (Terurut)\n";
        cout << "4. Tampilkan Pre-order\n";
        cout << "5. Tampilkan Post-order\n";
        cout << "6. Tampilkan Nilai Terendah\n";
        cout << "7. Tampilkan Nilai Tertinggi\n";
        cout << "8. Tampilkan Statistik\n";
        cout << "9. Keluar\n";
        cout << "========================================\n";
        cout << "Pilih: ";
        cin >> pilih;

        if (pilih == 1) {
            cout << "Masukkan Nilai: "; cin >> nilai;
            root = insertNode(root, nilai);
            cout << "-> Nilai " << nilai << " berhasil ditambahkan!\n";
        } else if (pilih == 2) {
            cout << "Cari Nilai: "; cin >> nilai;
            if (searchNode(root, nilai)) {
                cout << "-> Nilai " << nilai << " Ditemukan.\n";
            } else {
                cout << "-> Nilai " << nilai << " Tidak Ditemukan.\n";
            }
        } else if (pilih == 3) {
            cout << "\n--- Daftar Nilai (In-order) ---\n";
            inorder(root);
            cout << "\n";
        } else if (pilih == 4) {
            cout << "\n--- Daftar Nilai (Pre-order) ---\n";
            preorder(root);
            cout << "\n";
        } else if (pilih == 5) {
            cout << "\n--- Daftar Nilai (Post-order) ---\n";
            postorder(root);
            cout << "\n";
        } else if (pilih == 6) {
            int minVal = findMin(root);
            if (minVal != -1) {
                cout << "-> Nilai terendah: " << minVal << "\n";
            } else {
                cout << "-> Belum ada data.\n";
            }
        } else if (pilih == 7) {
            int maxVal = findMax(root);
            if (maxVal != -1) {
                cout << "-> Nilai tertinggi: " << maxVal << "\n";
            } else {
                cout << "-> Belum ada data.\n";
            }
        } else if (pilih == 8) {
            int count = countNodes(root);
            if (count > 0) {
                long long total = sumNilai(root);
                double rataRata = static_cast<double>(total) / count;
                cout << "\n--- Statistik Nilai ---\n";
                cout << "Jumlah Data: " << count << "\n";
                cout << "Total Nilai: " << total << "\n";
                cout << "Rata-rata: " << rataRata << "\n";
            } else {
                cout << "-> Belum ada data untuk dianalisis.\n";
            }
        }

    } while (pilih != 9);

    cout << "Program selesai.\n";
    return 0;
}

Node* insertNode(Node* root, int nilai) {
    if (!root) {
        return new Node(nilai);
    }
    if (nilai < root->nilai) {
        root->left = insertNode(root->left, nilai);
    } else {
        root->right = insertNode(root->right, nilai);
    }
    return root;
}

bool searchNode(Node* root, int nilai) {
    if (!root) {
        return false;
    }
    if (root->nilai == nilai) {
        return true;
    }
    if (nilai < root->nilai) {
        return searchNode(root->left, nilai);
    }
    return searchNode(root->right, nilai);
}

void inorder(Node* root) {
    if (!root) return;
    inorder(root->left);
    cout << root->nilai << " ";
    inorder(root->right);
}

void preorder(Node* root) {
    if (!root) return;
    cout << root->nilai << " ";
    preorder(root->left);
    preorder(root->right);
}

void postorder(Node* root) {
    if (!root) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->nilai << " ";
}

int findMin(Node* root) {
    if (!root) return -1;
    while (root->left) {
        root = root->left;
    }
    return root->nilai;
}

int findMax(Node* root) {
    if (!root) return -1;
    while (root->right) {
        root = root->right;
    }
    return root->nilai;
}

int countNodes(Node* root) {
    if (!root) return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}

long long sumNilai(Node* root) {
    if (!root) return 0;
    return root->nilai + sumNilai(root->left) + sumNilai(root->right);
}