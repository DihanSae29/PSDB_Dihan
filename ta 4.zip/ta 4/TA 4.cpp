#include <iostream>
using namespace std;

const int MAX = 100;
string st[MAX];
int topIdx = -1;

bool isEmpty() {
    return topIdx == -1;
}
bool isFull() {
    return topIdx == MAX - 1;
}
void push(string x) {
    if (isFull()) {
        cout << "Tumpukan penuh\n";
        return;
    }
    st[++topIdx] = x;
    cout << "Masukkan Dokumen " << x << " berhasil\n";
}

void pop() {
    if (isEmpty()) {
        cout << "Tumpukan kosong\n";
        return;
    }
    cout << "Keluarkan Dokumen " << st[topIdx--] << " berhasil\n";
}

void peek() {
    if (isEmpty()) {
        cout << "Tumpukan kosong\n";
        return;
    }
    cout << "Dokumen teratas: " << st[topIdx] << '\n';
}
void display() {
    if (isEmpty()) {
        cout << "Tumpukan kosong\n";
        return;
    }
    cout << "Isi tumpukan (atas ke bawah): ";
    for (int i = topIdx; i >= 0; --i) {
        cout << st[i] << ", ";
    }
    cout << '\n';
}

int main() {
int pilih;
string val;
    do {
        cout << "\n=== Tumpuk Dokumen ===\n";
        cout << "1. Masukkan Dokumen\n";
        cout << "2. Ambil Dokumen\n";
        cout << "3. Dokumen Teratas\n";
        cout << "4. Tampilkan Dokumen\n";
        cout << "5. Keluar\n";
        cout << "Pilih: ";
        cin >> pilih;
        cin.ignore();

        if (pilih == 1) { cout << "Masukkan Dokumen: ";
            getline(cin, val);
            push(val); 
        }
        else if (pilih == 2) pop();
        else if (pilih == 3) peek();
        else if (pilih == 4) display();
    }
    while (pilih != 5);
    return 0;
}